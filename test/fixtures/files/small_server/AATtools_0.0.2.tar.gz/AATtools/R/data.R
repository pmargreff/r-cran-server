#' AAT examining approach bias for erotic stimuli
#'
#' AAT
#'
#' @docType data
#'
#' @usage erotica
#'
#' @format An object of class \code{"data.frame"}
#'
#' @keywords datasets
#'
#' @references Kahveci, S., Van Bockstaele, B.D., & Wiers, R.W. (in preparation).
#' Pulling for Pleasure? Erotic Approach-Bias Associated With Porn Use, Not Problems. DOI:10.17605/OSF.IO/6H2RJ
#'
#' @source \href{https://osf.io/6h2rj/}{osf.io repository}
#'
"erotica"
# erotica<-read.csv("./../data/erotica.csv")
# erotica$subject%<>%as.factor()
# erotica%>%dplyr::group_by(subject)%>%dplyr::summarise(meanrt=mean(RT),sdrt=sd(RT),ct=n())
# erotica%<>%dplyr::filter(!(subject %in% c(13, 42,40,32,55)))
# save(erotica,file="./data/erotica.RData")
